/*--------------------------------------------------------------------
                                                                                      
                                                                                      
                        COPYRIGHT (C) 2008, IRSV Corporation
                        ALL RIGHTS RESERVED
                                                                                      
 This source code has been made available to you by IRSV on an
 AS-IS basis. Anyone receiving this source code is licensed under IRSV
 copyrights to use it in any way he or she deems fit, including copying it,
 modifying it, compiling it, and redistributing it either with or without
 modifications. Any person who transfers this source code or any derivative
 work must include the IRSV copyright notice and this paragraph in
 the transferred software.
 1.0    Initial net software                       CCL   2009.02.10
                                                                                      
-----------------------------------------------------------------------*/
#ifndef _CLINET_API_H_
#define _CLINET_API_H_

//#define TIRNETCLIENT_EXPORTS

//#ifdef TIRNETCLIENT_EXPORTS
//#define TIRNETCLIENT_API extern "C" __declspec(dllexport)
#define TIRNETCLIENT_API
//#else
//#define TIRNETCLIENT_API __declspec(dllimport)
//#endif

//#define TIRNETCLIENT_API __declspec(dllexport)

#ifdef SDK_LIB
#include "NetSocket.h"
#else
#include "netdefine.h"
#endif

typedef enum { CAMERA_640 = 0, CAMERA_336 = 1, CAMERA_324 = 2, CAMERA_384 = 3, CAMERA_640_480 = 4, CAMERA_384_2 = 5, CAMERA_640_2 = 6 }CamType;
#define SERIALNO_LEN 		32
#define IPSTRING_LEN 		30

#define CAMERA_ACTION_DO_FFC			0x01   // ���ƻ�о��һ�ε��嶯��
#define CAMERA_ACTION_STOP_AUTOFFC		0x02   //�ص��Զ�����У��
#define CAMERA_ACTION_START_AUTOFFC		0x03    //�����Զ�����У��





typedef struct {
	SINT8 sSerialNumber[SERIALNO_LEN];  //���к�
	UINT8 byAlarmInPortNum;		     //DVR�����������
	UINT8 byAlarmOutPortNum;		//DVR�����������    //GPIO �������
	UINT8 camType;				//�������
	UINT8 byCamResolution;		//��������������� �����о�ķֱ��� CAMERA_640 = 0 , CAMERA_336=1 , CAMERA_324 = 2 , CAMERA_384 = 3, CAMERA_640_480=4, CAMERA_384_2 =5, CAMERA_640_2 =6
	UINT8 frameRate;				//DVR ͨ������             //����
	UINT8 byStartChan;			   //  //����
	UINT8 userId;              //�û�id����λ��λ�������Ǹ�����
	UINT8 login;
	SINT8 sIPaddr[IPSTRING_LEN];   //�������IP��ַ
	UINT16 uPort;                  //��������Ķ˿ں�
	UINT32 frameLen;              //һ֡�����ݵĳ���
	SOCKET playSocket;            //���ŵ�socket

}NET_SERVER_DEVICEINFO, *LPNET_SERVER_DEVICEINFO;

TIRNETCLIENT_API BOOL   NET_VIDEO_Init();
TIRNETCLIENT_API INT32  NET_VIDEO_Login(char *sDVRIP,UINT32 wDVRPort,LPNET_SERVER_DEVICEINFO lpDeviceInfo);
TIRNETCLIENT_API INT32  NET_VIDEO_GetDevinfo(char *sDVRIP, UINT32 wDVRPort, LPNET_SERVER_DEVICEINFO lpDeviceInfo);
TIRNETCLIENT_API INT32  NET_VIDEO_Logout(LPNET_SERVER_DEVICEINFO lpDeviceInfo);
TIRNETCLIENT_API INT32  NET_VIDEO_RealPlay(char *sServerIP, UINT32 wServerPort, LPNET_SERVER_DEVICEINFO lpDeviceInfo);
TIRNETCLIENT_API INT32  NET_VIDEO_StopRealPlay(LPNET_SERVER_DEVICEINFO lpDeviceInfo);
TIRNETCLIENT_API INT32  NET_VIDEO_RevData(char *pDataBuf, UINT32 buffersize, int *cnt, LPNET_SERVER_DEVICEINFO lpDeviceInfo);
TIRNETCLIENT_API INT32   NET_VIDEO_RebootDevice(LPNET_SERVER_DEVICEINFO lpDeviceInfo);
TIRNETCLIENT_API INT32  NET_VIDEO_SetIPConfig(LPNET_SERVER_DEVICEINFO lpDeviceInfo, void*  lpInBuffer);
TIRNETCLIENT_API INT32  NET_VIDEO_SetFrameRate(LPNET_SERVER_DEVICEINFO lpDeviceInfo, UINT32 framRate);
TIRNETCLIENT_API INT32  NET_VIDEO_CAMERA_ACTION(LPNET_SERVER_DEVICEINFO lpDeviceInfo, UINT32 commandflag);
TIRNETCLIENT_API INT32  NET_VIDEO_AutoFocus(LPNET_SERVER_DEVICEINFO lpDeviceInfo);






#endif
