/*--------------------------------------------------------------------
                                                                                      
                                                                                      
                        COPYRIGHT (C) 2008, IRSV Corporation
                        ALL RIGHTS RESERVED
                                                                                      
 This source code has been made available to you by IRSV on an
 AS-IS basis. Anyone receiving this source code is licensed under IRSV
 copyrights to use it in any way he or she deems fit, including copying it,
 modifying it, compiling it, and redistributing it either with or without
 modifications. Any person who transfers this source code or any derivative
 work must include the IRSV copyright notice and this paragraph in
 the transferred software.
 1.0    Initial net software                       CCL   2009.02.10
                                                                                      
-----------------------------------------------------------------------*/
//#include "stdafx.h"
#include <string.h>
#include <stdio.h>
#include <sys/types.h>
#include <errno.h>
#include "Clinet_API.h"
//#include "TirNetInterface.h"
//#include "netserver.h"
#include "NetSocket.h"
#include <iostream>
#include <unistd.h>
//#include <WinSock2.h>

using namespace std;



#define NET_SERVER_LOGIN			0x84
#define NET_SERVER_GET_DEVINFO		0x85
#define NET_SERVER_GET_REALPLAY		0xab
#define NET_SERVER_GET_STOPPLAY		0xad
#define NET_SERVER_GET_LOGOUT		0xaa

#define NET_SERVER_REBOOT_DEV		0xbe
#define NET_SERVER_SET_IP			0xbd

#define NET_SERVER_SETFRAMERATE     0xC2   // ����֡�ʣ�������ֵ���÷��Ͷ���֡��

#define NET_SERVER_CAMERA_ACTION	0xCF   // ���ƻ�о��һ�ζ���

#define NET_SERVER_AUTOFOCUS        0xE0   //�Զ��۽�
#define NET_SERVER_ZOOM_ADD           0xE1  //����Ŵ�
#define NET_SERVER_ZOOM_RED           0xE2 //������С


#define CONFIG_ACTIVE_FLAG          0x5a5aa5a5  
#define CAMERA_ACTION_FLAG          0x5500aa00  



void init_socket_dll(void)
{
	static bool init_Socket_flag = false;

	if(init_Socket_flag == false)
	{
#ifdef WIN32
		 WSADATA wsadata;//WSADATA�ṹ������Ҫ������ϵͳ��֧�ֵ�Winsock�汾��Ϣ
		if( WSAStartup( MAKEWORD(2,2),&wsadata )!=0 )//��ʼ��Winsock 2.2
		{
			 printf("WSAStartup�޷���ʼ����");
			 TRACE("WSAStartup�޷���ʼ����");
		}
#endif
		
		init_Socket_flag = true;
	}
}
BOOL  NET_VIDEO_Init()
{
	init_socket_dll();

	return TRUE;
}

INT32  NET_VIDEO_Login(char *sDVRIP, UINT32 wDVRPort, LPNET_SERVER_DEVICEINFO lpDeviceInfo)
{
	unsigned int userId = 0, usedindex = 0;
	char *sUserName = "admin";
	char *sPassword = "123456";
	SOCKET Socket;
	unsigned char cmdbuffer[84];
	unsigned char cmdreceive[1024];

	int cmdlen = 84;
	memset(cmdbuffer, 0, 84);

	//usedindex = cServer.GetNoUseServerClient();

	//the command length
	((unsigned int *)cmdbuffer)[0] = 84;

	//the command type
	((unsigned int *)cmdbuffer)[1] = NET_SERVER_LOGIN;

	((unsigned short *)cmdbuffer)[40] = 0x84;

	memcpy(cmdbuffer + 16, sUserName, 32);
	memcpy(cmdbuffer + 48, sPassword, 16);
	memcpy(cmdbuffer + 64, sDVRIP, 16);

	
	if (!ConnectSever(&Socket, sDVRIP, wDVRPort))
	{
		TRACE("Login Connect %s faile\n", sDVRIP);
		return -1;
	}

	TRACE("Login Connect %s OK\n", sDVRIP);

	if (SendPactket(&Socket,(void *)cmdbuffer, cmdlen) != cmdlen)
	{
		return -2;
	}

	TRACE("Login send %d bytes\n", cmdlen);

	cmdlen = 76;
	if (ReceivePacket(Socket, &cmdreceive, cmdlen) != 76)
	{
		TRACE("Login rece  faile\n");

		return -1;
	}
	TRACE("Login rece  %d bytes\n", cmdlen);


	lpDeviceInfo->uPort = wDVRPort;
	//strcpy_s(lpDeviceInfo->sIPaddr, sDVRIP);
	strcpy(lpDeviceInfo->sIPaddr, sDVRIP);
	//TirNetClient.m_pCmdPort = wDVRPort;

	//strcpy_s(TirNetClient.m_sIP, sDVRIP);

	userId = ((unsigned int *)cmdreceive)[2];
	lpDeviceInfo->userId = userId;

	lpDeviceInfo->login = TRUE;

/*
	cServerClient.m_lUserId = userId;
	cServerClient.m_lReloginUserId = userId;
	TirNetClient.m_lReloginUserId = userId;
	TirNetClient.m_serverId = userId;

	TirNetClient.m_dServerIndex = usedindex;


	cServerClient.m_lUserId = userId;
*/

	//	cServerClient.serverinfo.m_csServerIP.Format("%s",sDVRIP);
	//	cServerClient.serverinfo.m_csServerAdminName.Format("%s",sUserName);
	//cServerClient.serverinfo.m_wServerPort = wDVRPort;
//	cServerClient.serverinfo.m_lServerID = usedindex;
	//	cServerClient.serverinfo.m_csServerAdminPasswd.Format("%s",sPassword);
	//cServerClient.login = TRUE;
	NET_VIDEO_GetDevinfo(sDVRIP, wDVRPort, lpDeviceInfo);

	///	cServerClient.StartHeartBeat();   //debug




	return 0;
}




//Get device information: 84 bytes,command type is 0x85.
// --------------------------------------------------------
// | 4 length | 4 command type | 8 userID | 68  reserverd |
// --------------------------------------------------------
/***************************************************************
Description:
Get device information.

Parameters:
sDVRIP: the IP address.
wDVRPort: the connect port.
userId: user id.
lpDeviceInfo: device information.

Returns:
TRUE: login success.
****************************************************************/
INT32 NET_VIDEO_GetDevinfo(char *sDVRIP, UINT32 wDVRPort, LPNET_SERVER_DEVICEINFO lpDeviceInfo)
{

	unsigned char cmdbuffer[84];
	unsigned char cmdreceive[1024];
	int cmdlen = 84;
	int usedindex = 0;
	int GetBottomUserId = lpDeviceInfo->userId;
	//GetBottomUserId = cServer.GetBottomUserId(usedindex);
	//if(GetBottomUserId==-1)
	//	return FALSE;

	memset(cmdbuffer, 0, 84);
	//the command length
	((unsigned int *)cmdbuffer)[0] = 84;

	//the command type
	((unsigned int *)cmdbuffer)[1] = NET_SERVER_GET_DEVINFO;

	((unsigned int *)cmdbuffer)[2] = GetBottomUserId;

	SOCKET Socket;


	if (!ConnectSever(&Socket, sDVRIP, wDVRPort))
	{
		TRACE("GetDevinfo %s faile\n", sDVRIP);
		return -1;
	}

	TRACE("GetDevinfo %s OK\n", sDVRIP);

	if (SendPactket(&Socket, (void *)cmdbuffer, cmdlen) != cmdlen)
	{
		return -2;
	}

	TRACE("GetDevinfo %d bytes\n", cmdlen);

	cmdlen = 76;
	if (ReceivePacket(Socket, &cmdreceive, cmdlen) != 76)
	{
		TRACE("Login rece  faile\n");

		return -1;
	}



	unsigned int cpylen = 38;//(unsigned int)((unsigned int)&lpDeviceInfo->userId - (unsigned int)lpDeviceInfo);

	if (((unsigned int *)cmdreceive)[1] == 0x06)
	{
		memcpy(lpDeviceInfo, cmdreceive + 20, cpylen);
	}

	return 0;
}



//ͼ��Ԥ��
INT32  NET_VIDEO_RealPlay(char *sServerIP, UINT32 wServerPort, LPNET_SERVER_DEVICEINFO lpDeviceInfo)
{
	unsigned char cmdbuffer[120];
	int cmdlen = 36;
	unsigned char cmdreceive[1024];
	//	LONG result=0;
	int usedindex = 0;
	int GetBottomUserId = lpDeviceInfo->userId;
	//	GetBottomUserId = cServer.GetBottomUserId(usedindex);
	//	if(GetBottomUserId==-1)
	//		return FALSE;
	SOCKET Socket;
	memset(cmdbuffer, 0, 36);
	//the command length
	((unsigned int *)cmdbuffer)[0] = 36;

	//the command type
	((unsigned int *)cmdbuffer)[1] = NET_SERVER_GET_REALPLAY;

	((unsigned int *)cmdbuffer)[2] = GetBottomUserId;
	

	if (!ConnectSever(&Socket, sServerIP, wServerPort))
	{
		return -1;
	}


	if (SendPactket(&Socket, (void *)cmdbuffer, cmdlen) != cmdlen )
	{
		return -2;
	}
	cmdlen = 20;

	if (ReceivePacket(Socket, &cmdreceive, cmdlen) != 20)
	{
		return -3;
	}

	TRACE("%d,%d\n", ((unsigned int *)cmdreceive)[0], ((unsigned int *)cmdreceive)[3]);
	if (((unsigned int *)cmdreceive)[0] == 0x1A)
	{
		if (((unsigned int *)cmdreceive)[3] != 0)
		{
			return -4;
		}
	}

	lpDeviceInfo->playSocket = Socket;

	UINT32 m_nDataLen;
	CamType cam_type = (CamType)lpDeviceInfo->byCamResolution;
	if (cam_type == CAMERA_640)
	{
		m_nDataLen = 640 * 512 * 2;
	}
	else if (cam_type == CAMERA_336)
	{
		m_nDataLen = 336 * 256 * 2;
	}
	else if (cam_type == CAMERA_324)
	{
		m_nDataLen = 324 * 256 * 2;
	}
	else if (cam_type == CAMERA_384)
	{
		m_nDataLen = 384 * 288 * 2;
	}
	else if (cam_type == CAMERA_640_480)
	{
		m_nDataLen = 640 * 480 * 2;
	}
	else if (cam_type == CAMERA_384_2)
	{
		m_nDataLen = 384 * 288 * 2 * 2;
	}
	else if (cam_type == CAMERA_640_2)
	{
		m_nDataLen = 640 * 512 * 2 * 2;
	}
	else
	{
		m_nDataLen = 0;
	}
	lpDeviceInfo->frameLen = m_nDataLen;

	TRACE("usedindex = %d,lUserID = %d.\n", usedindex, 0);

	///	cServerClient.StartVideoDecodeThread();

	return 0;
}


//cnt �� �յ����ֽڳ���,������ǰ��4��int�ͣ� type���յ��ַ�������
//pDataBuf   bufferָ��
//int buffersize  buffer��С
// int *cnt ��ȥ���ݴ�С
//int *type  ��������
INT32  NET_VIDEO_RevData(char *pDataBuf, UINT32 buffersize, int *cnt, LPNET_SERVER_DEVICEINFO lpDeviceInfo)
{
	//	char pcm[4096];
	int usedindex = 0;
	//	int GetBottomUserId = -1;
	//	GetBottomUserId = cServer.GetBottomUserId(usedindex);
	//	if(GetBottomUserId==-1)
	//		return FALSE;
	if (pDataBuf == NULL)
	{
		return FALSE;
	}

	//int CTirNetClient::RecvData(char *pDataBuf, int nBufLen, int *type)
	//{
		int nRef = 0;
	//	m_bHFrame = FALSE;
	

		SOCKET playSocket = lpDeviceInfo->playSocket;

		UINT32 m_nDataLen = lpDeviceInfo->frameLen;
		if (m_nDataLen>0)
		{
			if (m_nDataLen > buffersize)  //��������buffer ������
			{
			//	nRef = m_dataSock.ReceivePacket(m_pFrame + (m_recvLen - m_nDataLen), m_nDataLen);
			//	memcpy(pDataBuf, m_pFrame + (m_recvLen - m_nDataLen), nBufLen);
				TRACE("Buffer ������ ### %d�� %d\n\r", m_nDataLen, buffersize);
				return -4;
			}
			else
			{
				nRef = ReceivePacket(playSocket, pDataBuf, m_nDataLen);


				//	TRACE("Rece data %d,  need %d,  %d, %d,\n\r",nRef,  m_nDataLen, tmp1, tmp2);
			}
			if (nRef == -1)
			{
				return nRef;
			}
			*cnt = nRef;
		//	m_nDataLen -= nRef;

			return 0;
		}

		return -3;

}


INT32  NET_VIDEO_StopRealPlay(LPNET_SERVER_DEVICEINFO lpDeviceInfo)
{
	unsigned char cmdbuffer[32];

	int cmdlen = 32;
	int usedindex = 0;
	int GetBottomUserId = lpDeviceInfo->userId;

	if (usedindex == -1)
		return FALSE;
	SOCKET Socket;

	//cServerClient.m_bExitDisplay = FALSE;

	//	GetBottomUserId = cServer.GetBottomUserId(usedindex);
	//	if(GetBottomUserId==-1)
	//		return FALSE;

	memset(cmdbuffer, 0, 32);
	//the command length
	((unsigned int *)cmdbuffer)[0] = 32;

	//the command type
	((unsigned int *)cmdbuffer)[1] = NET_SERVER_GET_STOPPLAY;

	((unsigned int *)cmdbuffer)[2] = GetBottomUserId;

	((unsigned int *)cmdbuffer)[3] = 0;  //channel = 0;

	if (!ConnectSever(&Socket, lpDeviceInfo->sIPaddr, lpDeviceInfo->uPort))
	{
		return -1;
	}

	if (SendPactket(&Socket,(void *)cmdbuffer, cmdlen) != cmdlen)
	{
		return -2;
	}

	if (ReceivePacket(Socket, cmdbuffer, cmdlen) != cmdlen)
	{
		return -3;
	}


	///	cServerClient.StopVideoDecodeThread();
	///	Sleep(100);

	return 0;
}


INT32  NET_VIDEO_Logout(LPNET_SERVER_DEVICEINFO lpDeviceInfo)
{
	//	BOOL bresult=TRUE;
	unsigned char cmdbuffer[32];
	int cmdlen = 32;

	//Stop the heart beat
	int usedindex = 0;
	int GetBottomUserId = lpDeviceInfo->userId;
	//	GetBottomUserId = cServer.GetBottomUserId(usedindex);
	//	if(GetBottomUserId==-1)
	//		return FALSE;

	//	if(lUserID)
	//		return FALSE;

//	cServerClient.StopHeartBeat();

	//	Sleep(200);
	SOCKET Socket;

	memset(cmdbuffer, 0, 32);
	//the command length
	((unsigned int *)cmdbuffer)[0] = 32;

	//the command type
	((unsigned int *)cmdbuffer)[1] = NET_SERVER_GET_LOGOUT;

	((unsigned int *)cmdbuffer)[2] = GetBottomUserId;

	if (!ConnectSever(&Socket, lpDeviceInfo->sIPaddr, lpDeviceInfo->uPort))
	{
		return -1;
	}
	///	TirNetClient.m_cmdSock.Exit();

	if ( SendPactket(&Socket, (void *)cmdbuffer, cmdlen) != cmdlen)
	{
		return -2;
	}

	cmdlen = 20;
	if (ReceivePacket(Socket, cmdbuffer, cmdlen) != cmdlen)
	{
		return -3;
	}
	//	cServer.m_bServerNum--;
	//	if(cServer.m_bServerNum<0)
	//	cServer.m_bServerNum = 0;

//	cServerClient.Logout();

#ifdef WIN32
	Sleep(200);
#else
	usleep(200*1000);
#endif
	//usleep(200*1000);

	Disconnect(&Socket);  //�ص�control socket


	return 0;
}

// �����豸����
INT32  NET_VIDEO_RebootDevice(LPNET_SERVER_DEVICEINFO lpDeviceInfo)
{
	unsigned char cmdbuffer[256];

	int cmdlen = 16;
	int usedindex = lpDeviceInfo->userId;

	memset(cmdbuffer, 0, 256);
	SOCKET Socket;

	//the command length
	((unsigned int *)cmdbuffer)[0] = cmdlen;

	//the command type
	((unsigned int *)cmdbuffer)[1] = NET_SERVER_REBOOT_DEV;

	((unsigned int *)cmdbuffer)[2] = usedindex;

	((unsigned int *)cmdbuffer)[3] = CONFIG_ACTIVE_FLAG;


	if (!ConnectSever(&Socket, lpDeviceInfo->sIPaddr, lpDeviceInfo->uPort))
	{
		return -1;
	}
	///	TirNetClient.m_cmdSock.Exit();

	if (SendPactket(&Socket, (void *)cmdbuffer, cmdlen) != cmdlen)
	{
		return -2;
	}

	cmdlen = 20;
	if (ReceivePacket(Socket, cmdbuffer, cmdlen) != cmdlen)
	{
		return -3;
	}


	if (((unsigned int *)cmdbuffer)[1] == NET_SERVER_REBOOT_DEV)
	{
		if (((unsigned int *)cmdbuffer)[3] == 0)
			return	0;
		else
			return -4;
	}
	else
		return -5;
}


//����ip����
INT32  NET_VIDEO_SetIPConfig(LPNET_SERVER_DEVICEINFO lpDeviceInfo, void*  lpInBuffer)
{
	unsigned char cmdbuffer[268];

	int cmdlen = 12 + sizeof(APP_CONFIG);
	int usedindex = lpDeviceInfo->userId;
	SOCKET Socket;

	memset(cmdbuffer, 0, 268);
	//the command length
	((unsigned int *)cmdbuffer)[0] = cmdlen;

	//the command type
	((unsigned int *)cmdbuffer)[1] = NET_SERVER_SET_IP;

	((unsigned int *)cmdbuffer)[2] = usedindex;
	memcpy(cmdbuffer + 12, lpInBuffer, sizeof(APP_CONFIG));


	if (!ConnectSever(&Socket, lpDeviceInfo->sIPaddr, lpDeviceInfo->uPort))
	{
		return -1;
	}
	///	TirNetClient.m_cmdSock.Exit();

	if (SendPactket(&Socket, (void *)cmdbuffer, cmdlen) != cmdlen)
	{
		return -2;
	}

	cmdlen = 20;
	if (ReceivePacket(Socket, cmdbuffer, cmdlen) != cmdlen)
	{
		return -3;
	}


	if (((unsigned int *)cmdbuffer)[1] == NET_SERVER_SET_IP)
	{
		if (((unsigned int *)cmdbuffer)[3] == 0)
			return	0;
		else
			return -4;
	}
	else
		return -5;

}

//framRate ֡�ʣ�һ�����֡
INT32  NET_VIDEO_SetFrameRate(LPNET_SERVER_DEVICEINFO lpDeviceInfo, UINT32 framRate)
{
	unsigned char cmdbuffer[32];
	SOCKET Socket;

	int cmdlen = 32;
	int GetBottomUserId = lpDeviceInfo->userId;


	memset(cmdbuffer, 0, 32);

	((unsigned int *)cmdbuffer)[0] = 32;

	((unsigned int *)cmdbuffer)[1] = NET_SERVER_SETFRAMERATE;

	((unsigned int *)cmdbuffer)[2] = GetBottomUserId;

	((unsigned int *)cmdbuffer)[3] = framRate;  //channel = 0;


	if (!ConnectSever(&Socket, lpDeviceInfo->sIPaddr, lpDeviceInfo->uPort))
	{
		return -1;
	}

	if (SendPactket(&Socket, (void *)cmdbuffer, cmdlen) != cmdlen)
	{
		return -2;
	}


	if (ReceivePacket(Socket, cmdbuffer, cmdlen) != cmdlen)
	{
		return -3;
	}


	if (((unsigned int *)cmdbuffer)[1] == NET_SERVER_SETFRAMERATE)
	{
		if (((unsigned int *)cmdbuffer)[3] == 0)
			return	0;
		else
			return -4;
	}
	else
		return -5;


}


//�Զ��۽�
INT32  NET_VIDEO_AutoFocus(LPNET_SERVER_DEVICEINFO lpDeviceInfo)
{
	unsigned char cmdbuffer[32];
	SOCKET Socket;

	int cmdlen = 32;
	int GetBottomUserId = lpDeviceInfo->userId;


	memset(cmdbuffer, 0, 32);

	((unsigned int *)cmdbuffer)[0] = 32;

	((unsigned int *)cmdbuffer)[1] = NET_SERVER_AUTOFOCUS;

	((unsigned int *)cmdbuffer)[2] = GetBottomUserId;

	((unsigned int *)cmdbuffer)[3] = 0;  //channel = 0;


	if (!ConnectSever(&Socket, lpDeviceInfo->sIPaddr, lpDeviceInfo->uPort))
	{
		return -1;
	}

	if (SendPactket(&Socket, (void *)cmdbuffer, cmdlen) != cmdlen)
	{
		return -2;
	}


	if (ReceivePacket(Socket, cmdbuffer, cmdlen) != cmdlen)
	{
		return -3;
	}


	if (((unsigned int *)cmdbuffer)[1] == NET_SERVER_AUTOFOCUS)
	{
		if (((unsigned int *)cmdbuffer)[3] == 0)
			return	0;
		else
			return -4;
	}
	else
		return -5;


}



// �����������
INT32  NET_VIDEO_CAMERA_ACTION(LPNET_SERVER_DEVICEINFO lpDeviceInfo, UINT32 commandflag)
{
	unsigned char cmdbuffer[32];

	int cmdlen = 32;
	int usedindex = lpDeviceInfo->userId;

	memset(cmdbuffer, 0, sizeof(cmdbuffer));
	SOCKET Socket;

	//the command length
	((unsigned int *)cmdbuffer)[0] = cmdlen;

	//the command type
	((unsigned int *)cmdbuffer)[1] = NET_SERVER_CAMERA_ACTION;

	((unsigned int *)cmdbuffer)[2] = usedindex;

	((unsigned int *)cmdbuffer)[3] = CAMERA_ACTION_FLAG;

	((unsigned int *)cmdbuffer)[4] = commandflag;

	if (!ConnectSever(&Socket, lpDeviceInfo->sIPaddr, lpDeviceInfo->uPort))
	{
		return -1;
	}
	///	TirNetClient.m_cmdSock.Exit();

	if (SendPactket(&Socket, (void *)cmdbuffer, cmdlen) != cmdlen)
	{
		return -2;
	}

	cmdlen = 20;
	if (ReceivePacket(Socket, cmdbuffer, cmdlen) != cmdlen)
	{
		return -3;
	}


	if (((unsigned int *)cmdbuffer)[1] == NET_SERVER_CAMERA_ACTION)
	{
		if (((unsigned int *)cmdbuffer)[3] == 0)
			return	0;
		else
			return -4;
	}
	else
		return -5;
}


#if 0

//���ö˿ںŵ�ֵ
//port =1���� =2  ��ӦGPIO1 , GPIO2  value = 0 �� 1
//����0 ���óɹ�
LONG  NET_VIDEO_SetGPIO(int port,int value)
{
	unsigned char cmdbuffer[84];
	unsigned char cmdreceive[1024];
//	CString sIP;
	int cmdlen = 20;
	int usedindex = 0;
	int GetBottomUserId = 0;
	//GetBottomUserId = cServer.GetBottomUserId(usedindex);
	//if(GetBottomUserId==-1)
	//	return FALSE;

	if(TirNetClient.m_pCmdPort == 0)
	{
		TRACE("Not login the device\r\n");
		return -1;
	}


	memset(cmdbuffer,0,84);
	//the command length
	((unsigned int *)cmdbuffer)[0]=20;

	//the command type
	((unsigned int *)cmdbuffer)[1]=0xB9; //#define	NET_SERVER_SETGPIO	0xB9    //����GPIO,Ϊ�������ƾ�ͷ������

	((unsigned int *)cmdbuffer)[2]=GetBottomUserId;

     ((unsigned int *)cmdbuffer)[3]=port;
     ((unsigned int *)cmdbuffer)[4]=value;

	if(!TirNetClient.ConnectControl(TirNetClient.m_sIP,TirNetClient.m_pCmdPort))
	{
		return -2;
	}

	if(TirNetClient.m_ctlSock.SendPactket((void *)cmdbuffer, cmdlen) != cmdlen)
	{
		return -3;
	}
	cmdlen = 24;

	if(!TirNetClient.m_ctlSock.ReceivePacket(&cmdreceive,cmdlen))
	{
		return -4;
	}

	if(((unsigned int *)cmdreceive)[3] == 0)  //flag ��׼�� =0 ��ʾִ����ȷ
	{
		return 0;
	}	


	return -5;
}

//����ip����
BOOL  NET_VIDEO_SetIPConfig(void*  lpInBuffer)
{
	unsigned char cmdbuffer[268];
	unsigned char cmdreceive[1024];

	int cmdlen = 12+sizeof(APP_CONFIG);
	int usedindex=0;

	memset(cmdbuffer,0,268);
	//the command length
	((unsigned int *)cmdbuffer)[0]=cmdlen;

	//the command type
	((unsigned int *)cmdbuffer)[1]=0xBD;

	((unsigned int *)cmdbuffer)[2]=0;
	 memcpy(cmdbuffer+12,lpInBuffer,sizeof(APP_CONFIG));

	if(!TirNetClient.ConnectCommand(TirNetClient.m_sIP,TirNetClient.m_pCmdPort))
	{
		return FALSE;
	}

	if(TirNetClient.m_cmdSock.SendPactket((void *)cmdbuffer, cmdlen) != cmdlen)
	{
		return FALSE;
	}
	cmdlen = 20;

	if(!TirNetClient.m_cmdSock.ReceivePacket(&cmdreceive,cmdlen))
	{
		return FALSE;
	}

	if(((unsigned int *)cmdreceive)[1] == 0xBD)
	{
		if(((unsigned int *)cmdreceive)[4]==0)
			return	TRUE;
		else
			return FALSE;
	}	
	else
		return FALSE;
	return TRUE;
}




//��ȡ���������¶�
//����0 �ɹ�
LONG  NET_VIDEO_GetSensorTemp(int *value)
{
	unsigned char cmdbuffer[84];
	unsigned char cmdreceive[512];
	const unsigned char cmdData[] = {0x6E, 0x00, 0x00, 0x20, 0x00, 0x02, 0x79, 0x3F, 0x00, 0x00, 0x00, 0x00};  //6E 00 00 20 00 02 79 3F 00 00 00 00 
    int reclen;
	int cmdlen = 84;
	int usedindex = 0;
	int GetBottomUserId = 0;
	//GetBottomUserId = cServer.GetBottomUserId(usedindex);
	//if(GetBottomUserId==-1)
	//	return FALSE;
	
	if(TirNetClient.m_pCmdPort == 0)
	{
		TRACE("Not login the device\r\n");
		return -1;
	}

	cmdlen = 12+sizeof(cmdData);
	memset(cmdbuffer,0,84);
	//the command length
	((unsigned int *)cmdbuffer)[0]=cmdlen;

	//the command type
	((unsigned int *)cmdbuffer)[1]=0xBA; //#define	NET_SERVER_GETSENSORTMP	0xBA   

	((unsigned int *)cmdbuffer)[2]=GetBottomUserId;

	memcpy(&cmdbuffer[12], cmdData,sizeof(cmdData));

	if(!TirNetClient.ConnectControl(TirNetClient.m_sIP,TirNetClient.m_pCmdPort))
	{
		return -1;
	}

	if(TirNetClient.m_ctlSock.SendPactket((void *)cmdbuffer, cmdlen) != cmdlen)
	{
		return -2;
	}
	
	cmdlen = 24;

	reclen = TirNetClient.m_ctlSock.ReceivePacket(&cmdreceive,cmdlen);
	if(reclen < 24 )  //���յĳ��Ȳ���
	{
		return -3;
	}

	if(cmdreceive[12] == 0x6E && cmdreceive[15] == 0x20  && cmdreceive[17] == 0x02)  //
	{
		*value =  cmdreceive[20]<<8 |  cmdreceive[21];

		return 0;
	}	


	return -4;
}

// ���ͻ�о�Ŀ����������ȡ��������
/// cmd �����buffer�� 
//respond ��о���ص�Ӧ�� 
//resp_len ����ȥ��ʾrespond������buffer�ռ��С�������ص�����ĳ���
LONG  NET_VIDEO_SendSensorCommand(unsigned char *cmd, int cmd_len, unsigned char *respond, int *resp_len)
{
	unsigned char cmdbuffer[512];
	unsigned char cmdreceive[512];
    int reclen;
	int cmdlen = 84;
	int usedindex = 0;
	int GetBottomUserId = 0;

	if(cmd == NULL || respond == NULL || cmd_len == 0)
	{
		TRACE("SendSensorCommand arg err.\r\n");
		return -1; 
	}
	
	if(TirNetClient.m_pCmdPort == 0)
	{
		TRACE("Not login the device\r\n");
		return -1;
	}

	cmdlen = 12+cmd_len;
	if(cmdlen > sizeof(cmdbuffer))
	{
		return -1;
	}
	memset(cmdbuffer,0,sizeof(cmdbuffer));
	//the command length
	((unsigned int *)cmdbuffer)[0]=cmdlen;

	//the command type
	((unsigned int *)cmdbuffer)[1]=0xBC; // #define	NET_SERVER_SENDCAMERACMD	0xBC    //����о����������������յ���о���ص�������ص��������ݲ��̶�����

	((unsigned int *)cmdbuffer)[2]=GetBottomUserId;

	memcpy(&cmdbuffer[12], cmd, cmd_len);

	if(!TirNetClient.ConnectControl(TirNetClient.m_sIP,TirNetClient.m_pCmdPort))
	{
		return -1;
	}

	if(TirNetClient.m_ctlSock.SendPactket((void *)cmdbuffer, cmdlen) != cmdlen)
	{
		return -2;
	}
	
	//cmdlen = 24;
	
	reclen = TirNetClient.m_ctlSock.ReceiveBuffer(cmdreceive,sizeof(cmdreceive));   // ��receive buffer �ĺ��������� receive packet

	//printf("comand rece lend =%d. \n\r", reclen);
	if(reclen <= 0)/// SOCKET_ERROR)
	{
			*resp_len = 0;
			return -3;
	}
	if(reclen > 12)
	{
		reclen -= 12;
		reclen = reclen <= *resp_len? reclen:*resp_len;
		memcpy(respond, &cmdreceive[12],reclen);
		*resp_len = reclen;

		return 0;
	}
	 

	*resp_len = 0;

	return -4;



}



// �������ݸ�����Ԥ���Ĵ��ڣ�����ת����ȥ�����ȴ�10mS��ȡ��������
/// cmd �����buffer�� 
//respond ��о���ص�Ӧ�� 
//resp_len ����ȥ��ʾrespond������buffer�ռ��С�������ص�����ĳ���
LONG  NET_VIDEO_SendUartCommand(unsigned char *cmd, int cmd_len, unsigned char *respond, int *resp_len)
{
	unsigned char cmdbuffer[512];
	unsigned char cmdreceive[512];
    int reclen;
	int cmdlen;
	int usedindex = 0;
	int GetBottomUserId = 0;

	if(cmd == NULL || respond == NULL || cmd_len == 0)
	{
		TRACE("SendUartCommand arg err.\r\n");
		return -1; 
	}
	
	if(TirNetClient.m_pCmdPort == 0)
	{
		TRACE("Not login the device\r\n");
		return -1;
	}

	cmdlen = 12+cmd_len;
	if(cmdlen > sizeof(cmdbuffer))
	{
		return -1;
	}
	memset(cmdbuffer,0,sizeof(cmdbuffer));
	//the command length
	((unsigned int *)cmdbuffer)[0]=cmdlen;

	//the command type
	((unsigned int *)cmdbuffer)[1]= 0xC1;//#define NET_SERVER_SENDUARTCMD      0xC1   //�����ڷ����������ͨ������ת����ȥ��


	((unsigned int *)cmdbuffer)[2]=GetBottomUserId;

	memcpy(&cmdbuffer[12], cmd, cmd_len);

	if(!TirNetClient.ConnectControl(TirNetClient.m_sIP,TirNetClient.m_pCmdPort))
	{
		return -1;
	}

	if(TirNetClient.m_ctlSock.SendPactket((void *)cmdbuffer, cmdlen) != cmdlen)
	{
		return -2;
	}
	
	//cmdlen = 24;

	reclen = TirNetClient.m_ctlSock.ReceiveBuffer(cmdreceive,sizeof(cmdreceive));   // ��receive buffer �ĺ��������� receive packet

	if(reclen == SOCKET_ERROR)
	{
			*resp_len = 0;
			return -3;
	}
	if(reclen > 12)
	{
		reclen -= 12;
		reclen = reclen <= *resp_len? reclen:*resp_len;
		memcpy(respond, &cmdreceive[12],reclen);
	*resp_len = reclen;

	return 0;
	}
	 

	*resp_len = 0;

	return -4;



}

LONG SendHeartCmd(LONG userID,int index)
{
	unsigned char cmdbuffer[84];
	unsigned char cmdreceive[84];

//	CString sIP;
	int cmdlen = 32;
	int usedindex=userID;
	int GetBottomUserId = 0;
	//GetBottomUserId = cServer.GetBottomUserId(usedindex);
	//if(GetBottomUserId==-1)
	//	return FALSE;

	memset(cmdbuffer,0,84);
	//the command length
	((unsigned int *)cmdbuffer)[0]=32;

	//the command type
	((unsigned int *)cmdbuffer)[1]=0xb1;

	((unsigned int *)cmdbuffer)[2]=GetBottomUserId;

	if(!TirNetClient.ConnectHeart(TirNetClient.m_sIP,TirNetClient.m_pCmdPort))
	{
		return -1;
	}

		
	TirNetClient.m_heartSock.SendPactket((void *)cmdbuffer, cmdlen);

	cmdlen = 20;

	if(!TirNetClient.m_heartSock.ReceivePacket(&cmdreceive,cmdlen))
	{
		return -2;
	}

	if(((unsigned int *)cmdreceive)[1] == 0x1A)
	{
		TRACE("the heart return.\n");
		if(((unsigned int *)cmdreceive)[4]==NET_DVR_USERNOTEXIST)
		{
/*			NET_SERVER_DEVICEINFO DeviceInfo;
			NET_VIDEO_ReLogin(usedindex,(char *)(LPCTSTR)cServerClient.serverinfo.m_csServerIP,cServerClient.serverinfo.m_wServerPort,
				(char *)(LPCTSTR)cServerClient.serverinfo.m_csServerAdminName,(char *)(LPCTSTR)cServerClient.serverinfo.m_csServerAdminPasswd,&DeviceInfo);
			if(cServerClient.m_bExitDisplay)
			{
				NET_VIDEO_StopRealPlay(usedindex);	
				cServerClient.m_bExitDisplay = TRUE;
				NET_VIDEO_ReRealPlay(usedindex,(char *)(LPCTSTR)cServerClient.serverinfo.m_csServerIP,cServerClient.serverinfo.m_wServerPort,GetBottomUserId,&cServerClient.ClientInfo);
			}
*/		}

	}	


	return 0;
}


//Get net config: 32 bytes,command type is 0x86.
// --------------------------------------------------------
// | 4 length | 4 command type | 8 userID | 16  reserverd |
// --------------------------------------------------------
/***************************************************************
Description:
		Get net config information.
		
Parameters:
		sDVRIP: the IP address.
		wDVRPort: the connect port.
		userId: user id.
		lpDeviceInfo: device information.
		
Returns:
		TRUE: net config.
****************************************************************/
LONG NET_VIDEO_GetNetinfo(char *sDVRIP,WORD wDVRPort,LONG userId,LPNET_SERVER_NETCFG lpNetcfg )
{

	unsigned char cmdbuffer[32];
	unsigned char cmdreceive[1024];
	int cmdlen = 32;
	int usedindex=userId;
	int GetBottomUserId = 0;
//	GetBottomUserId = cServer.GetBottomUserId(usedindex);
//	if(GetBottomUserId==-1)
//		return FALSE;

	memset(cmdbuffer,0,32);
	//the command length
	((unsigned int *)cmdbuffer)[0]=32;

	//the command type
	((unsigned int *)cmdbuffer)[1]=0x86;

	((unsigned int *)cmdbuffer)[2]=GetBottomUserId;


	if(!TirNetClient.ConnectCommand(TirNetClient.m_sIP,TirNetClient.m_pCmdPort))
	{
		return -1;
	}

	if(TirNetClient.m_cmdSock.SendPactket((void *)cmdbuffer, cmdlen) != cmdlen)
	{
		return -2;
	}
	cmdlen = 272;

	if(!TirNetClient.m_cmdSock.ReceivePacket(&cmdreceive,cmdlen))
	{
		return -3;
	}
	if(((unsigned int *)cmdreceive)[1] == 0x07)
	{
		memcpy(lpNetcfg,cmdreceive+20,sizeof(NET_SERVER_NETCFG));
	}
	
	return 0;
}



//login command: 84 bytes,command type is 0x84.
// ----------------------------------------------------------------------------------------------------------
// | 4 length | 4 command type | 8 userID | 32 user name | 16 passwd | 16 ip address | 2 port | 2 reserverd |
// ----------------------------------------------------------------------------------------------------------
/***************************************************************
Description:
		net user login.
		
Parameters:
		sDVRIP: the IP address.
		wDVRPort: the connect port.
		sUserName: user name.
		sPassword: user password.
		lpDeviceInfo: device information.
		//userindex for top user
		//serverid is for bottom user
		
Returns:
		TRUE: login success.
****************************************************************/








UINT8*  NET_VIDEO_GetBuffer(LONG lUserID)
{
	int usedindex=lUserID;
	int GetBottomUserId = -1;
//	GetBottomUserId = cServer.GetBottomUserId(usedindex);
//	if(GetBottomUserId==-1)
//		return FALSE;

	return TirNetClient.m_pFrame;
}


#define NET_SERVER_SETWARNTEMP      0xBF   //���ñ����¶�
#define NET_SERVER_GETWARNTEMP      0xC0   //��ȡ�����¶�
//���ñ����¶�ֵ,���õ��¶�ֵ��λ�� 0.1���϶�
BOOL  NET_VIDEO_SetWarnTemp(int tmp_01C)
{
	unsigned char cmdbuffer[32];

	int cmdlen = 32;
	int usedindex=0;
	int GetBottomUserId =0;

	if(usedindex==-1)
		return FALSE;

	cServerClient.m_bExitDisplay = FALSE;	


	memset(cmdbuffer,0,32);

	((unsigned int *)cmdbuffer)[0]=32;

	((unsigned int *)cmdbuffer)[1]=NET_SERVER_SETWARNTEMP;

	((unsigned int *)cmdbuffer)[2]=GetBottomUserId;

	((unsigned int *)cmdbuffer)[3]=0;  //channel = 0;

	(( int *)cmdbuffer)[4]=tmp_01C;  //channel = 0;

	if(!TirNetClient.ConnectControl(TirNetClient.m_sIP,TirNetClient.m_pCmdPort))
	{
		return FALSE;
	}

	if(TirNetClient.m_ctlSock.SendPactket((void *)cmdbuffer, cmdlen) != cmdlen)
	{
		return FALSE;
	}

	if(!TirNetClient.m_ctlSock.ReceivePacket(cmdbuffer,cmdlen))
	{
		return FALSE;
	}


///	cServerClient.StopVideoDecodeThread();
///	Sleep(100);

	return TRUE;
}
BOOL  NET_VIDEO_GetWarnTemp(int *tmp_01C)
{
	unsigned char cmdbuffer[32];

	int cmdlen = 32;
	int usedindex=0;
	int GetBottomUserId =0;

	if(usedindex==-1)
		return FALSE;

	cServerClient.m_bExitDisplay = FALSE;	


	memset(cmdbuffer,0,32);

	((unsigned int *)cmdbuffer)[0]=32;

	((unsigned int *)cmdbuffer)[1]=NET_SERVER_GETWARNTEMP;

	((unsigned int *)cmdbuffer)[2]=GetBottomUserId;

	((unsigned int *)cmdbuffer)[3]=0;  //channel = 0;

	

	if(!TirNetClient.ConnectControl(TirNetClient.m_sIP,TirNetClient.m_pCmdPort))
	{
		return FALSE;
	}

	if(TirNetClient.m_ctlSock.SendPactket((void *)cmdbuffer, cmdlen) != cmdlen)
	{
		return FALSE;
	}

	if(!TirNetClient.m_ctlSock.ReceivePacket(cmdbuffer,cmdlen))
	{
		return FALSE;
	}

	*tmp_01C = (( int *)cmdbuffer)[4];

	return TRUE;
}




#endif
