// SDK_Test_App.cpp : �������̨Ӧ�ó������ڵ㡣
//

#include <iostream>
#include <stdio.h>
#include <vector>
#include "Clinet_API.h"
#include "ImgProc.h"
#include <opencv2/opencv.hpp>

using namespace cv;
using namespace std;

#define BUFFER_SIZE 640*1024*2
char buffer[BUFFER_SIZE];

int main()
{
	BOOL bInit = NET_VIDEO_Init();
	int ret;

	if (bInit)
	{
		NET_SERVER_DEVICEINFO deviceInfo;
		char *ip = "192.168.1.201";
		int port = 8000;
		ret = NET_VIDEO_Login(ip, port, &deviceInfo);

		if (ret == 0)
		{			
			ret = NET_VIDEO_RealPlay(ip, port, &deviceInfo);
			if (ret == 0)
			{
				int i = 1000;
				while (i--)
				{
					int cnt;
					int bResult = NET_VIDEO_RevData((char*)buffer, BUFFER_SIZE, &cnt, &deviceInfo);
					
					int m_imageW = 640;
					int m_imageH = 512;
					ImgPara imgSrc, imgDst;
					imgSrc.nWidth = m_imageW;
					imgSrc.nHeight = m_imageH;
					imgSrc.wBpps = 14;
					imgSrc.wChannel = 1;
					imgSrc.pData =(void *)buffer;
					char pData[m_imageW*m_imageH];

					imgDst.nWidth = m_imageW;
					imgDst.nHeight = m_imageH;
					imgDst.wBpps = 8;
					imgDst.wChannel = 1;
					imgDst.pData =(void *)pData;
					Change14bitTO8bit( &imgSrc, &imgDst,  FALSE,FALSE);

					Mat ImageSrc = Mat(512, 640, CV_8UC1, imgDst.pData);
					imshow("src", ImageSrc);
					waitKey(1);
					imwrite("./img/save.png", ImageSrc);

					if (bResult != 0)
					{
						printf("no data ret =%d\n\r", bResult);
						// break;
						continue;
					}
					printf("Receive1 left %5d data: %d bytes\n\r", i, cnt);
				}
				printf("Receive test 100 frame over\n\r");
				ret = NET_VIDEO_StopRealPlay(&deviceInfo);
				if (ret == 0)
				{
					printf("Stop play ok\n\r");
				}
				else
				{
					printf("Stop play fail\n\r");
				}

				ret = NET_VIDEO_Logout(&deviceInfo);
				if (ret == 0)
				{
					printf("Logout ok\n\r");
				}
				else
				{
					printf("Logout fail\n\r");
				}
			}
		}
	}
	printf("input to over");
	getchar();
	return 0;

}