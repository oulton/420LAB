#/bin/sh


cd  /opt/LBAS/lib

echo "create link to dynamic library"
if [ -d "/opt/LBAS/lib/64" ]; then
ldconfig -n ./64
fi

if [ -d "/opt/LBAS/lib/32" ]; then
ldconfig -n ./32
fi

if [ -d "/opt/LBAS/lib/armhf" ]; then
ldconfig -n ./armhf
fi

if [ -d "/opt/LBAS/lib/aarch64" ]; then
ldconfig -n ./aarch64
fi

if [ -d "/opt/LBAS/lib/arm-none" ]; then
ldconfig -n ./arm-none
fi
